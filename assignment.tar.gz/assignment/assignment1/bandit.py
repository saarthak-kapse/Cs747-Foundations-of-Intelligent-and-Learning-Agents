import argparse
import os
import random
import numpy as np
import math  

parser = argparse.ArgumentParser()
parser.add_argument('--instance', type=str)
parser.add_argument('--algorithm', type=str)
parser.add_argument('--randomSeed', type=str)
parser.add_argument('--epsilon', type=str)
parser.add_argument('--horizon', type=str)
args = parser.parse_args()

def round_robin(instance=args.instance, algorithm=args.algorithm, randomSeed=args.randomSeed, epsilon=args.epsilon, horizon=args.horizon):
	instance_f = open(instance,'r')
	bandits_probability_list = []
	for instance_prob in instance_f:
		bandits_probability_list.append(float(instance_prob))
	number_of_bandits = len(bandits_probability_list)   
	np.random.seed(randomSeed)
	obs_list = []
	for i in range(horizon):    
		obs_list.append(np.random.choice([0, 1], p=[1-bandits_probability_list[i%number_of_bandits], 
								bandits_probability_list[i%number_of_bandits]]))
	
	total_reward = np.sum(obs_list)
	max_reward = np.max(bandits_probability_list)*horizon
	regret = max_reward - total_reward
	# print('Regret:',regret,'Max Reward:',max_reward,'Total Reward:',total_reward)
	return regret

def epsilon_greedy(instance=args.instance, algorithm=args.algorithm, randomSeed=args.randomSeed, epsilon=args.epsilon, horizon=args.horizon):
	instance_f = open(instance,'r')
	bandits_probability_list = []
	bandits_id_dict = {}
	bandits_mean_list = []
	for i,instance_prob in enumerate(instance_f):
		bandits_probability_list.append(float(instance_prob))
		bandits_id_dict[i] = 0

	number_of_bandits = len(bandits_probability_list)   
	bandits_mean_list = [0]*number_of_bandits
	np.random.seed(randomSeed)
	obs_list = []
	for i in range(horizon):
		# print(bandits_mean_list)
		if np.random.choice([0,1], p = [epsilon, 1-epsilon]) == 0:
			pulled_id = np.random.choice(list(bandits_id_dict.keys()))
			obs_list.append(np.random.choice([0, 1], p=[1-bandits_probability_list[pulled_id], 
												bandits_probability_list[pulled_id]]))
			bandits_id_dict[pulled_id] += 1
			bandits_mean_list[pulled_id] = (bandits_mean_list[pulled_id]*(bandits_id_dict[pulled_id]-1) + obs_list[-1])/bandits_id_dict[pulled_id]
			
		else:
			if bandits_mean_list.count(0) != len(bandits_mean_list):
				best_arm = np.argmax(bandits_mean_list)
				obs_list.append(np.random.choice([0, 1], p=[1-bandits_probability_list[best_arm], 
												bandits_probability_list[best_arm]]))
				bandits_id_dict[best_arm] += 1
				bandits_mean_list[best_arm] = (bandits_mean_list[best_arm]*(bandits_id_dict[best_arm]-1) + obs_list[-1])/bandits_id_dict[best_arm]
				
			else:
				best_arm =  np.random.choice(list(bandits_id_dict.keys()))
				obs_list.append(np.random.choice([0, 1], p=[1-bandits_probability_list[best_arm], 
												bandits_probability_list[best_arm]]))
				bandits_id_dict[best_arm] += 1
				bandits_mean_list[best_arm] = (bandits_mean_list[best_arm]*(bandits_id_dict[best_arm]-1) + obs_list[-1])/bandits_id_dict[best_arm]

	total_reward = np.sum(obs_list)
	max_reward = np.max(bandits_probability_list)*horizon
	regret = max_reward - total_reward
	# print('Regret:',regret,'Max Reward:',max_reward,'Total Reward:',total_reward)
	return regret

def ucb(instance=args.instance, algorithm=args.algorithm, randomSeed=args.randomSeed, epsilon=args.epsilon, horizon=args.horizon):
	instance_f = open(instance,'r')
	bandits_probability_list = []
	for instance_prob in instance_f:
		bandits_probability_list.append(float(instance_prob))

	number_of_bandits = len(bandits_probability_list)   
	bandits_mean_list = [0]*number_of_bandits
	bandits_counts_list = [0]*number_of_bandits
	np.random.seed(randomSeed)
	obs_list = []

	if horizon >= number_of_bandits:

		for i in range(number_of_bandits):
			bandits_mean_list[i] = np.random.choice([0, 1], p=[1-bandits_probability_list[i], 
												bandits_probability_list[i]])
			bandits_counts_list[i] += 1
			obs_list.append(bandits_mean_list[i])

		for i in range(horizon-number_of_bandits):
			arm_id = 0
			max_index = 0 
			for j in range(number_of_bandits):
				index = bandits_mean_list[j] + math.sqrt(2*(math.log(i+number_of_bandits))/bandits_counts_list[j])
				if index > max_index:
					max_index = index 
					arm_id = j

			obs_list.append(np.random.choice([0, 1], p=[1-bandits_probability_list[arm_id], 
												bandits_probability_list[arm_id]]))
			bandits_counts_list[arm_id] += 1
			bandits_mean_list[arm_id] = (bandits_mean_list[arm_id]*(bandits_counts_list[arm_id]-1) + obs_list[-1])/bandits_counts_list[arm_id]
	
	else:

		for i in range(horizon):
			bandits_mean_list[i] = np.random.choice([0, 1], p=[1-bandits_probability_list[i], 
												bandits_probability_list[i]])
			bandits_counts_list[i] += 1
			obs_list.append(bandits_mean_list[i])

	# regret = 1
	total_reward = np.sum(obs_list)
	max_reward = np.max(bandits_probability_list)*horizon
	regret = max_reward - total_reward
	# print('Regret:',regret,'Max Reward:',max_reward,'Total Reward:',total_reward)
	return regret

def kl_ucb(instance=args.instance, algorithm=args.algorithm, randomSeed=args.randomSeed, epsilon=args.epsilon, horizon=args.horizon):
	instance_f = open(instance,'r')
	bandits_probability_list = []
	for instance_prob in instance_f:
		bandits_probability_list.append(float(instance_prob))

	number_of_bandits = len(bandits_probability_list)   
	bandits_mean_list = [0]*number_of_bandits
	bandits_counts_list = [0]*number_of_bandits
	np.random.seed(randomSeed)
	obs_list = []

	if horizon >= number_of_bandits:

		for i in range(number_of_bandits):
			bandits_mean_list[i] = np.random.choice([0, 1], p=[1-bandits_probability_list[i], 
												bandits_probability_list[i]])
			bandits_counts_list[i] += 1
			obs_list.append(bandits_mean_list[i])

			if bandits_mean_list[i] == 0:
				bandits_mean_list[i] = 0.0001


		for i in range(horizon-number_of_bandits):
			arm_id = 0
			max_q = 0 
			for j in range(number_of_bandits):
				q = converge(bandits_mean_list[j],bandits_counts_list[j],i+number_of_bandits)
				if q > max_q:
					max_q = q 
					arm_id = j

			obs_list.append(np.random.choice([0, 1], p=[1-bandits_probability_list[arm_id], 
												bandits_probability_list[arm_id]]))
			bandits_counts_list[arm_id] += 1
			bandits_mean_list[arm_id] = (bandits_mean_list[arm_id]*(bandits_counts_list[arm_id]-1) + obs_list[-1])/bandits_counts_list[arm_id]
	
	else:

		for i in range(horizon):
			bandits_mean_list[i] = np.random.choice([0, 1], p=[1-bandits_probability_list[i], 
												bandits_probability_list[i]])
			bandits_counts_list[i] += 1
			obs_list.append(bandits_mean_list[i])

	# regret = 1
	total_reward = np.sum(obs_list)
	max_reward = np.max(bandits_probability_list)*horizon
	regret = max_reward - total_reward
	# print('Regret:',regret,'Max Reward:',max_reward,'Total Reward:',total_reward)
	return regret

def converge(mean,count,time):
	if mean == 1:
		return 1

	start = mean 
	stop = 1
	q = (start + stop)/2
	constant = ((math.log(time)+3*math.log(math.log(time)))/count)
	if constant<=0:
		return mean

	kl_value = kl_calculate(mean,q)
	while stop - start >= 0.0001:
		kl_value = kl_calculate(mean,q)
		if kl_value>constant:
			stop = q 
			q = (start+stop)/2
		else:
			start = q 
			q = (start+stop)/2

	return q

def kl_calculate(p,q):
	return p*(math.log(p/q)) + (1-p)*(math.log((1-p)/(1-q)))

def thompson_sampling(instance=args.instance, algorithm=args.algorithm, randomSeed=args.randomSeed, epsilon=args.epsilon, horizon=args.horizon):
	instance_f = open(instance,'r')
	bandits_probability_list = []
	for instance_prob in instance_f:
		bandits_probability_list.append(float(instance_prob))

	number_of_bandits = len(bandits_probability_list)   
	reward_count_list = [0]*number_of_bandits
	penalty_count_list = [0]*number_of_bandits
	np.random.seed(randomSeed)
	obs_list = []

	for i in range(horizon):
		arm_id = 0
		max_beta = 0 
		for j in range(number_of_bandits):
			beta = np.random.beta(reward_count_list[j]+1,penalty_count_list[j]+1)
			if beta > max_beta:
				max_beta = beta 
				arm_id = j

		obs_list.append(np.random.choice([0, 1], p=[1-bandits_probability_list[arm_id], 
												bandits_probability_list[arm_id]]))
		if obs_list[-1] == 1:
			reward_count_list[arm_id] += 1
		else:
			penalty_count_list[arm_id] += 1
	
	total_reward = np.sum(obs_list)
	max_reward = np.max(bandits_probability_list)*horizon
	regret = max_reward - total_reward
	# print('Regret:',regret,'Max Reward:',max_reward,'Total Reward:',total_reward)
	return regret


if args.algorithm == 'round-robin':
	regret = round_robin(args.instance, args.algorithm, int(args.randomSeed), float(args.epsilon), int(args.horizon))
elif args.algorithm == 'epsilon-greedy':
	regret = epsilon_greedy(args.instance, args.algorithm, int(args.randomSeed), float(args.epsilon), int(args.horizon))
elif args.algorithm == 'ucb':
	regret = ucb(args.instance, args.algorithm, int(args.randomSeed), float(args.epsilon), int(args.horizon))
elif args.algorithm == 'kl-ucb':
	regret = kl_ucb(args.instance, args.algorithm, int(args.randomSeed), float(args.epsilon), int(args.horizon))
elif args.algorithm == 'thompson-sampling':
	regret = thompson_sampling(args.instance, args.algorithm, int(args.randomSeed), float(args.epsilon), int(args.horizon))

# f= open("outputData.txt","a")
# f.write(args.instance +', '+ args.algorithm +', '+ str(args.randomSeed) +', '+ str(args.epsilon) +', '+ str(args.horizon) +', '+ str(regret)+'\n')
# f.close() 

print(args.instance +', '+ args.algorithm +', '+ str(args.randomSeed) +', '+ str(args.epsilon) +', '+ str(args.horizon) +', '+ str(regret)+'\n')
