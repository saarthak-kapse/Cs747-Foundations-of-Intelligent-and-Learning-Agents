for arg in "$@"
do
    case $arg in
        --instance)
        in="$2"
        shift 
        shift 
        ;;
        --algorithm)
        al="$2"
        shift 
        shift 
        ;;
        --randomSeed)
        rs="$2"
        shift 
        shift 
        ;;
        --epsilon)
        ep="$2"
        shift
        shift
        ;;
        --horizon)
        hz="$2"
        shift 
        shift 
        ;;
    esac
done

python3 bandit.py --instance $in --algorithm $al --randomSeed $rs --epsilon $ep --horizon $hz
