import os
import numpy as np 
import argparse
from pulp import *

parser = argparse.ArgumentParser()
parser.add_argument('--path')
parser.add_argument('--algorithm')
args = parser.parse_args()

def open_mdp(mdp_path):
	mdp_file = open(mdp_path,'r')
	mdp_file_lines = mdp_file.readlines()
	number_of_state = int(mdp_file_lines[0])
	number_of_actions = int(mdp_file_lines[1])
	discount_factor = float(mdp_file_lines[2*number_of_state*number_of_actions+2])
	type_of_mdp = mdp_file_lines[2*number_of_state*number_of_actions+3]

	reward_matrix = np.zeros((number_of_state,number_of_actions, number_of_state))
	transition_matrix = np.zeros((number_of_state,number_of_actions, number_of_state))

	for i,line in enumerate(mdp_file_lines[2:2+number_of_state*number_of_actions]):
		for j in range(number_of_state):
			reward_matrix[i//number_of_actions][i%number_of_actions][j] = line.split()[j]
			

	for i,line in enumerate(mdp_file_lines[2+number_of_state*number_of_actions:-2]):
		for j in range(len(line.split())):
			transition_matrix[i//number_of_actions][i%number_of_actions][j] = line.split()[j]

	return number_of_state, number_of_actions, reward_matrix, transition_matrix, discount_factor, type_of_mdp

def lp(mdp_path):

	number_of_state, number_of_actions, reward_matrix, transition_matrix, discount_factor, type_of_mdp = open_mdp(mdp_path)
	value_function = np.zeros(number_of_state)
	policy_function = np.zeros(number_of_state)

	prob = LpProblem("MDP", LpMinimize)
	variable_list = []
	for i in range(number_of_state):
		variable_list.append(str(i))
	variable_list_lp = LpVariable.dicts("v",variable_list)

	prob += lpSum([variable_list_lp[i] for i in variable_list]), "Objective Function"

	for current_state in range(number_of_state):
		for action in range(number_of_actions):
			prob += lpSum([transition_matrix[current_state][action][i]*\
					(reward_matrix[current_state][action][i]+discount_factor*variable_list_lp[str(i)]) 
					for i in range(number_of_state)]) <= variable_list_lp[str(current_state)],\
					 str(current_state)+'_'+str(action)
	
	if type_of_mdp == 'episodic':
		prob += variable_list_lp[variable_list[-1]] == 0
	
	prob.solve()

	for i,v in enumerate(prob.variables()):
		value_function[i] = v.varValue

	for current_state in range(number_of_state):
		max_sum = -1*float('Inf')
		best_action = 0
		for action in range(number_of_actions):
			temp_sum = 0
			for next_state in range(number_of_state):
				temp_sum += transition_matrix[current_state][action][next_state]*(
							reward_matrix[current_state][action][next_state]+discount_factor*value_function[next_state])
			if temp_sum > max_sum:
				max_sum = temp_sum
				best_action = action
		
		policy_function[current_state] = best_action

	for i in range(number_of_state):
		print(str.format('{:.6f}', value_function[i]) + "\t" + str(int(policy_function[i])))

def hpi(mdp_path):
	number_of_state, number_of_actions, reward_matrix, transition_matrix, discount_factor, type_of_mdp = open_mdp(mdp_path)
	
	policy_function = np.random.randint(number_of_actions, size=number_of_state)
	policy_change = -1

	while(policy_change!=0):
		value_function = np.zeros(number_of_state)
		change = 1
		while(change>1e-9):

			previous_value_function = value_function.copy()
			
			for current_state in range(number_of_state):
				temp_sum = 0
				action = policy_function[current_state]
				for next_state in range(number_of_state):
					temp_sum += transition_matrix[current_state][action][next_state]*(
								reward_matrix[current_state][action][next_state]+discount_factor*previous_value_function[next_state])

				value_function[current_state] = temp_sum

			change = abs(np.sum(abs(value_function)) - np.sum(abs(previous_value_function)))

		previous_policy_function = policy_function.copy()
		for current_state in range(number_of_state):
			max_sum = -1*float('Inf')
			best_action = 0
			for action in range(number_of_actions):
				temp_sum = 0
				for next_state in range(number_of_state):
					temp_sum += transition_matrix[current_state][action][next_state]*(
								reward_matrix[current_state][action][next_state]+discount_factor*value_function[next_state])
				if temp_sum > max_sum:
					max_sum = temp_sum
					best_action = action
			
			policy_function[current_state] = best_action
		
		if np.all(previous_policy_function == policy_function):
			policy_change = 0

	for i in range(number_of_state):
		print(str.format('{:.6f}', value_function[i]) + "\t" + str(int(policy_function[i])))

if args.algorithm == 'lp':
	lp(args.path)
elif args.algorithm == 'hpi':
	hpi(args.path)