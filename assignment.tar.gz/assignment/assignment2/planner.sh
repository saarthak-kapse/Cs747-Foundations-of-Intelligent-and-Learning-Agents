path=$2
algorithm=$4

python3 run.py --path $path --algorithm $algorithm