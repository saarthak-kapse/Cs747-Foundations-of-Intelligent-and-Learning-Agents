data_loc=$1
python3 TD.py $data_loc