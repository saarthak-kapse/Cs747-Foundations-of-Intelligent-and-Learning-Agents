import os
import numpy as np 
import sys 

data_file = open(sys.argv[1],"r")
data = data_file.readlines()

number_of_states = int(data[0])
number_of_actions = int(data[1])
discount_factor = float(data[2])
episode_array = np.zeros((len(data)-3,3))

for i,line in enumerate(data[3:-1]):
	line = line.split()
	episode_array[i][0] = int(line[0])
	episode_array[i][1] = int(line[1])
	episode_array[i][2] = float(line[2])
line = data[-1]
episode_array[-1][0] = int(line[0])
episode_array[-1][1] = None
episode_array[-1][2] = None


value_function =  np.random.rand(number_of_states)
state_count = np.zeros(number_of_states)
n_steps_TD = 10
alpha = 0.0001
stopping_condition = False
count = 0

for i in range(episode_array.shape[0]-1):
	current_state = int(episode_array[i][0])
	state_count[current_state] += 1
	n_steps_TD = min(n_steps_TD,episode_array.shape[0]-i-1)
	n_step_reward = 0
	for j in range(n_steps_TD):
		n_step_reward += (discount_factor**(j))*float(episode_array[i+j][2])
	n_step_state = int(episode_array[i+n_steps_TD][0])
	n_step_reward += (discount_factor**(n_steps_TD))*value_function[n_step_state]
	value_function[current_state] = value_function[current_state] \
					+ (1/state_count[current_state])*(n_step_reward - value_function[current_state])


while(stopping_condition is False):
	value_function_old = value_function.copy()
	for i in range(episode_array.shape[0]-1):
		current_state = int(episode_array[i][0])
		reward = float(episode_array[i][2])
		next_state = int(episode_array[i+1][0]) 
		value_function[current_state] = value_function[current_state] \
			+ alpha*(reward + discount_factor*value_function[next_state] - value_function[current_state])

	if count>50:
		stopping_condition = True
	elif count>10 and np.sum((value_function - value_function_old)*(value_function - value_function_old)) < 1e-6:
		stopping_condition = True

	count += 1

for i in range(number_of_states):
	print(value_function[i])
	