python3 task2.py 
python3 task3.py
python3 task4.py